console.log("welcome to javascript");
//welcome to javascript

console.table(["UI FullStack","Angular14","ReactJS","VueJS","NodeJS"]);
/*

┌─────────┬────────────────┐
│ (index) │     Values     │
├─────────┼────────────────┤
│    0    │ 'UI FullStack' │
│    1    │  'Angular14'   │
│    2    │   'ReactJS'    │
│    3    │    'VueJS'     │
│    4    │    'NodeJS'    │
└─────────┴────────────────┘
*/


console.log( 10+10 );           //20
console.log( 10+"10" );         //1010
console.log( 10+ +"10" );       //20
console.log( 10 - "10" );       //0
console.log( "10" * 10 );       //100
console.log( "10" / 10 );       //1
console.log( 10 / "0");         //Infinity
console.log( 10 / "A" );        //NaN
console.log( 10>9>8 );          //false


























