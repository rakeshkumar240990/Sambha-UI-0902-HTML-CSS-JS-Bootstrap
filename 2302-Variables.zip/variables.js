//string
//collection of "characters" called as "string"
//"" (double quotes) , ''(single quotes) and ``(backtick)
//``(backtick) operator introduced in "ES6"
//``(backtick) operator also called as "template literal"
//``(backtick) operator used to define the multiline (paragraphs) strings
var sub_one = "Angular14";
var sub_two = "NodeJS";
var sub_three = "MongoDB"; 
var mean_stack = `${sub_one}....${sub_two}....${sub_three}`;
console.log(mean_stack);
//Angular14....NodeJS....MongoDB



//number
//decimal
//double
//hexadecimal
//octal
//binary
var decimal_num = 100;
var double_num = 100.12345;
var hexadecimal_num = 0x123ABC;
var octal_num = 0o123;
var binary_num = 0b1010;
console.log( decimal_num, double_num, hexadecimal_num, octal_num, binary_num );
//100 100.12345 1194684 83 10


//boolean
//true --- 1
//false --- 0
var flag = true;
var flag1 = false;
console.log( flag );                //true
console.log( flag1 );               //false
console.log( true+true );           //2
console.log( true / false );        //Infinity
//==     (values)
//===    (values and datatype)
console.log( true == 1 );               //true
console.log( true === 1 );              //false
console.log( 10 == "10" );              //true
console.log( 10 === "10" );             //false


//undefined
var data;
console.log(data);                   //undefined


data = null;
console.log( data );                 //null



//arrays
var arr = ["Angular14","ReactJS","VueJS","NodeJS","MongoDB"];
//iterate
//ES6
//forEach()
arr.forEach((element,index)=>{
    console.log( element, index );
});




//json
//json stands for javascript object notation
//json also called as javascript objects
//Objects ---- {}
//Arrays  ---- []
//data    ---- key & value pairs
var obj = {
    "sub1":"RJS",
    "sub2":"NG14",
    "sub3":"VueJS",
    "sub4":"MongoDB"
};
console.log( obj.sub1, obj.sub2, obj.sub3, obj.sub4 );
//RJS NG14 VueJS MongoDB





//let
//let keyword introduced in ES6
//let keyword used to declare the variables


/*
    //for loop
    for(let i=0;i<5;i++){
        
    }

    console.log(i);                 //var: 5
                                    //let : ReferenceError: i is not defined

    //var keyword breaks the scope rule
    //let keyword obeys the scope rule
*/



/*
    //global variable
    let x = 100;


    //block in javascript
    {
        //local variable
        let x = 200;   
    }

    console.log( x );         //var : 200    //let : 100

    //global polluting issue raised because of "var" keyword
    //we can overcome global polluting issue by using "let" keyword
*/


/*
    let v1 = 100;
    let v1 = 200;
    console.log(v1);                //var : 200             //let : SyntaxError: Identifier 'v1' has already been declared

    //var keyword allows the duplicate variables
    //let keyword won't allows the duplicate variables
*/




/*
    //1) declare the variable
    //2) initilize the variable
    //3) access the variables
    console.log( x );
    let x = 100;
    //var : undefined           //let:ReferenceError: Cannot access 'x' before initialization
    //variable hoisting issue raised because of "var" keyword
    //we can overcome variable hoisting by using "let" keyword
*/


/*
                            var                                         let

        var keyword relesed in ES1                          let keyword released in ES6

        var keyword allows the duplicate                    let keyword won't allows the duplicate variables
        variables

        scope rule break by var keyword                     scope rule obey by let keyword

        global polluting issue raised by                    we can overcome global polluting issue by using
        var keyword                                         let keyword

        variable hoisting issue raised                      we can overcome variable hoisting issue by using 
        because of var keyword                              let keyword

        var members by default global                       let members are local members
        members

*/


//const
//const keyword also introduced in "ES6"
//const keyword used to "declare" the variables
//"reinitilization" not possible with const keyword

const c1 = 100;
//c1 = 200;                       //TypeError: Assignment to constant variable.


const arr1 = [10,20,30,40,50];
//arr1 = [];                  //TypeError: Assignment to constant variable.

arr1[0] = 100;
arr1[4] = 500;
arr1[5] = 600;
console.log( arr1 );                    //[ 100, 20, 30, 40, 500, 600 ]



const obj1 = {
    "sub_one" : "ReactJS",
    "sub_two" : "NodeJS",
    "sub_three" : "MongoDB"
};

//obj1 = {};                      //TypeError: Assignment to constant variable.

obj1.sub_one = "Angular14";
obj1.sub_two = "Go";
obj1.sub_three = "CassandraDB";
console.log( obj1 );            //{ sub_one: 'Angular14', sub_two: 'Go', sub_three: 'CassandraDB' }





























































































































































































