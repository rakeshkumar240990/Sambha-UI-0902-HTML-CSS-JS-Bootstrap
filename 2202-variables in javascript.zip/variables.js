//string
//collection of "characters" called as "string"
//"" (double quotes) , ''(single quotes) and ``(backtick)
//``(backtick) operator introduced in "ES6"
//``(backtick) operator also called as "template literal"
//``(backtick) operator used to define the multiline (paragraphs) strings
var sub_one = "Angular14";
var sub_two = "NodeJS";
var sub_three = "MongoDB"; 
var mean_stack = `${sub_one}....${sub_two}....${sub_three}`;
console.log(mean_stack);
//Angular14....NodeJS....MongoDB



//number
//decimal
//double
//hexadecimal
//octal
//binary
var decimal_num = 100;
var double_num = 100.12345;
var hexadecimal_num = 0x123ABC;
var octal_num = 0o123;
var binary_num = 0b1010;
console.log( decimal_num, double_num, hexadecimal_num, octal_num, binary_num );
//100 100.12345 1194684 83 10


//boolean
//true --- 1
//false --- 0
var flag = true;
var flag1 = false;
console.log( flag );                //true
console.log( flag1 );               //false
console.log( true+true );           //2
console.log( true / false );        //Infinity
//==     (values)
//===    (values and datatype)
console.log( true == 1 );               //true
console.log( true === 1 );              //false
console.log( 10 == "10" );              //true
console.log( 10 === "10" );             //false


//undefined
var data;
console.log(data);                   //undefined


data = null;
console.log( data );                 //null



//arrays
var arr = ["Angular14","ReactJS","VueJS","NodeJS","MongoDB"];
//iterate
//ES6
//forEach()
arr.forEach((element,index)=>{
    console.log( element, index );
});




//json
//json stands for javascript object notation
//json also called as javascript objects
//Objects ---- {}
//Arrays  ---- []
//data    ---- key & value pairs
var obj = {
    "sub1":"RJS",
    "sub2":"NG14",
    "sub3":"VueJS",
    "sub4":"MongoDB"
};
console.log( obj.sub1, obj.sub2, obj.sub3, obj.sub4 );
//RJS NG14 VueJS MongoDB






























































































